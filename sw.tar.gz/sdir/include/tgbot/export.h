#ifndef TGBOT_EXPORT_H
#define TGBOT_EXPORT_H

#ifndef TGBOT_API
#define TGBOT_API
#endif

#endif //TGBOT_EXPORT_H
